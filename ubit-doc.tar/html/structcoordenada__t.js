var structcoordenada__t =
[
    [ "x", "structcoordenada__t.html#a33a17a6edfd050d2b0e6d4c5affa9a41", null ],
    [ "y", "structcoordenada__t.html#a5feab8ee2a5a648b8c88656f4ec317fb", null ]
];