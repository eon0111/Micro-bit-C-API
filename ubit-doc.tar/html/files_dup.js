var files_dup =
[
    [ "acelerometro.c", "acelerometro_8c.html", "acelerometro_8c" ],
    [ "botones.c", "botones_8c.html", "botones_8c" ],
    [ "buzzer.c", "buzzer_8c.html", "buzzer_8c" ],
    [ "display.c", "display_8c.html", "display_8c" ],
    [ "misc.c", "misc_8c.html", "misc_8c" ],
    [ "sprites.h", "sprites_8h.html", "sprites_8h" ],
    [ "ubit.h", "ubit_8h.html", "ubit_8h" ]
];