var searchData=
[
  ['coordenada_5ft_12',['coordenada_t',['../structcoordenada__t.html',1,'']]]
];
