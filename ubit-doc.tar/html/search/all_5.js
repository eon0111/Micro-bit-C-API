var searchData=
[
  ['microbit_5finicializa_5fhardware_24',['microbit_inicializa_hardware',['../misc_8c.html#a1266222f9978ad2a61f052aad2cdc0e7',1,'microbit_inicializa_hardware():&#160;misc.c'],['../ubit_8h.html#a1266222f9978ad2a61f052aad2cdc0e7',1,'microbit_inicializa_hardware():&#160;misc.c']]],
  ['misc_2ec_25',['misc.c',['../misc_8c.html',1,'']]]
];
