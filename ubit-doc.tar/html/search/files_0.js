var searchData=
[
  ['acelerometro_2ec_30',['acelerometro.c',['../acelerometro_8c.html',1,'']]]
];
