var searchData=
[
  ['acelerometro_5finclinacion_5feje_5fx_37',['acelerometro_inclinacion_eje_x',['../acelerometro_8c.html#a73ffcf1f3c69bbd2dd6498316effc4f5',1,'acelerometro_inclinacion_eje_x():&#160;acelerometro.c'],['../ubit_8h.html#a73ffcf1f3c69bbd2dd6498316effc4f5',1,'acelerometro_inclinacion_eje_x():&#160;acelerometro.c']]],
  ['acelerometro_5finclinacion_5feje_5fy_38',['acelerometro_inclinacion_eje_y',['../acelerometro_8c.html#a2154bc2bdff0aa2c259f576923933212',1,'acelerometro_inclinacion_eje_y():&#160;acelerometro.c'],['../ubit_8h.html#a2154bc2bdff0aa2c259f576923933212',1,'acelerometro_inclinacion_eje_y():&#160;acelerometro.c']]],
  ['acelerometro_5finicializa_39',['acelerometro_inicializa',['../acelerometro_8c.html#a5fd0b6fd546f22ed220baf20ad244cc5',1,'acelerometro_inicializa():&#160;acelerometro.c'],['../ubit_8h.html#a5fd0b6fd546f22ed220baf20ad244cc5',1,'acelerometro_inicializa():&#160;acelerometro.c']]],
  ['acelerometro_5flectura_5fx_40',['acelerometro_lectura_x',['../acelerometro_8c.html#a169eee0556749ef07158f51026fdb7c4',1,'acelerometro_lectura_x():&#160;acelerometro.c'],['../ubit_8h.html#a169eee0556749ef07158f51026fdb7c4',1,'acelerometro_lectura_x():&#160;acelerometro.c']]],
  ['acelerometro_5flectura_5fy_41',['acelerometro_lectura_y',['../acelerometro_8c.html#a794e12f2d7bd8cd9a38111cb5b7a9c71',1,'acelerometro_lectura_y():&#160;acelerometro.c'],['../ubit_8h.html#a794e12f2d7bd8cd9a38111cb5b7a9c71',1,'acelerometro_lectura_y():&#160;acelerometro.c']]],
  ['acelerometro_5flectura_5fz_42',['acelerometro_lectura_z',['../acelerometro_8c.html#ae10a8bda4f78b34f257a52c5b4e8b081',1,'acelerometro_lectura_z():&#160;acelerometro.c'],['../ubit_8h.html#ae10a8bda4f78b34f257a52c5b4e8b081',1,'acelerometro_lectura_z():&#160;acelerometro.c']]]
];
