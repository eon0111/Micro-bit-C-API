var botones_8c =
[
    [ "boton_espera_pulsacion", "botones_8c.html#a4663bbc3ec477c4fd8bf5f644d8a0c7a", null ],
    [ "boton_pulsado", "botones_8c.html#a620464d75bf384eca4c7db41f811c22c", null ]
];