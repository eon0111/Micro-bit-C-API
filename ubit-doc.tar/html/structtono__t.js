var structtono__t =
[
    [ "duracion_ms", "structtono__t.html#a26a433b04f72ac2852a22838c67c9ab1", null ],
    [ "nota", "structtono__t.html#aa9ba11431ca89e589a2409000750ac8f", null ]
];