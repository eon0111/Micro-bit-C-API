var annotated_dup =
[
    [ "coordenada_t", "structcoordenada__t.html", "structcoordenada__t" ]
];