var searchData=
[
  ['acelerometro_2ec_39',['acelerometro.c',['../acelerometro_8c.html',1,'']]]
];
