var searchData=
[
  ['imagen_5ft_27',['imagen_t',['../ubit_8h.html#a62ea13a71b705592d09e89764692cdcd',1,'ubit.h']]],
  ['init_28',['init',['../misc_8c.html#a02fd73d861ef2e4aabb38c0c9ff82947',1,'misc.c']]]
];
