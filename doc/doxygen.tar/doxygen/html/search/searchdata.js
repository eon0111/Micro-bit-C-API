var indexSectionsWithContent =
{
  0: "abdimstu",
  1: "abdmsu",
  2: "abdimt",
  3: "i",
  4: "at"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "typedefs",
  4: "defines"
};

var indexSectionLabels =
{
  0: "Todo",
  1: "Archivos",
  2: "Funciones",
  3: "typedefs",
  4: "defines"
};

