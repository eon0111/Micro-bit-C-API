var searchData=
[
  ['boton_5fespera_5fpulsacion_52',['boton_espera_pulsacion',['../botones_8c.html#a4663bbc3ec477c4fd8bf5f644d8a0c7a',1,'boton_espera_pulsacion(boton_t b):&#160;botones.c'],['../ubit_8h.html#a4663bbc3ec477c4fd8bf5f644d8a0c7a',1,'boton_espera_pulsacion(boton_t b):&#160;botones.c']]],
  ['boton_5fpulsado_53',['boton_pulsado',['../botones_8c.html#a620464d75bf384eca4c7db41f811c22c',1,'boton_pulsado(boton_t b):&#160;botones.c'],['../ubit_8h.html#a620464d75bf384eca4c7db41f811c22c',1,'boton_pulsado(boton_t b):&#160;botones.c']]],
  ['buzzer_5freproduce_5fnota_54',['buzzer_reproduce_nota',['../buzzer_8c.html#a8fbdbbfad51a8e79222b10272cb72587',1,'buzzer_reproduce_nota(nota_t n, int t_ms):&#160;buzzer.c'],['../ubit_8h.html#a8fbdbbfad51a8e79222b10272cb72587',1,'buzzer_reproduce_nota(nota_t n, int t_ms):&#160;buzzer.c']]]
];
