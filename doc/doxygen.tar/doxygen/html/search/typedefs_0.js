var searchData=
[
  ['imagen_5ft_67',['imagen_t',['../ubit_8h.html#a62ea13a71b705592d09e89764692cdcd',1,'ubit.h']]]
];
