var searchData=
[
  ['temp_5fbase_32',['TEMP_BASE',['../misc_8c.html#a988cceb9ccd460fea3674f7b8c5fef44',1,'misc.c']]],
  ['temp_5fdata_33',['TEMP_DATA',['../misc_8c.html#adc684174a0c8ca786a5a8fd1f95e03e6',1,'misc.c']]],
  ['temp_5fdatardy_34',['TEMP_DATARDY',['../misc_8c.html#a57e6c92134d09fef52b577bb99381a4c',1,'misc.c']]],
  ['temp_5ftask_5fstart_35',['TEMP_TASK_START',['../misc_8c.html#affc9390ebceabfe04c27e5717370901e',1,'misc.c']]],
  ['termometro_5flectura_36',['termometro_lectura',['../misc_8c.html#a08479db9e20ec26a78eb8c0790470870',1,'termometro_lectura():&#160;misc.c'],['../ubit_8h.html#a08479db9e20ec26a78eb8c0790470870',1,'termometro_lectura():&#160;misc.c']]],
  ['tmp_5fstep_37',['TMP_STEP',['../misc_8c.html#ad467fd9305e3163eae7efea4a1586e8c',1,'misc.c']]]
];
