var searchData=
[
  ['termometro_5flectura_66',['termometro_lectura',['../misc_8c.html#a08479db9e20ec26a78eb8c0790470870',1,'termometro_lectura():&#160;misc.c'],['../ubit_8h.html#a08479db9e20ec26a78eb8c0790470870',1,'termometro_lectura():&#160;misc.c']]]
];
