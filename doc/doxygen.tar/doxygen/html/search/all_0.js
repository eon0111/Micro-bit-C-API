var searchData=
[
  ['acc_0',['ACC',['../acelerometro_8c.html#a09fc148003f20ecc4834d4ea6aefb15c',1,'acelerometro.c']]],
  ['acc_5fctrl_5freg1_1',['ACC_CTRL_REG1',['../acelerometro_8c.html#a4261ed5ff8ba2ae0b2000c312f46d5ad',1,'acelerometro.c']]],
  ['acc_5fout_5fx_2',['ACC_OUT_X',['../acelerometro_8c.html#a83ea82a0ea23a77aad53a26efeee72b7',1,'acelerometro.c']]],
  ['acc_5fout_5fy_3',['ACC_OUT_Y',['../acelerometro_8c.html#a462e86f76f74f9b19a562683572ffb44',1,'acelerometro.c']]],
  ['acc_5fout_5fz_4',['ACC_OUT_Z',['../acelerometro_8c.html#a5aa358a5ac2183e9e1bd133229a42588',1,'acelerometro.c']]],
  ['acelerometro_2ec_5',['acelerometro.c',['../acelerometro_8c.html',1,'']]],
  ['acelerometro_5finclinacion_5feje_5fx_6',['acelerometro_inclinacion_eje_x',['../acelerometro_8c.html#a73ffcf1f3c69bbd2dd6498316effc4f5',1,'acelerometro_inclinacion_eje_x():&#160;acelerometro.c'],['../ubit_8h.html#a73ffcf1f3c69bbd2dd6498316effc4f5',1,'acelerometro_inclinacion_eje_x():&#160;acelerometro.c']]],
  ['acelerometro_5finclinacion_5feje_5fy_7',['acelerometro_inclinacion_eje_y',['../ubit_8h.html#a2154bc2bdff0aa2c259f576923933212',1,'acelerometro_inclinacion_eje_y():&#160;acelerometro.c'],['../acelerometro_8c.html#a2154bc2bdff0aa2c259f576923933212',1,'acelerometro_inclinacion_eje_y():&#160;acelerometro.c']]],
  ['acelerometro_5finicializa_8',['acelerometro_inicializa',['../acelerometro_8c.html#a5fd0b6fd546f22ed220baf20ad244cc5',1,'acelerometro_inicializa():&#160;acelerometro.c'],['../ubit_8h.html#a5fd0b6fd546f22ed220baf20ad244cc5',1,'acelerometro_inicializa():&#160;acelerometro.c']]],
  ['acelerometro_5flectura_5fx_9',['acelerometro_lectura_x',['../acelerometro_8c.html#a169eee0556749ef07158f51026fdb7c4',1,'acelerometro_lectura_x():&#160;acelerometro.c'],['../ubit_8h.html#a169eee0556749ef07158f51026fdb7c4',1,'acelerometro_lectura_x():&#160;acelerometro.c']]],
  ['acelerometro_5flectura_5fy_10',['acelerometro_lectura_y',['../acelerometro_8c.html#a794e12f2d7bd8cd9a38111cb5b7a9c71',1,'acelerometro_lectura_y():&#160;acelerometro.c'],['../ubit_8h.html#a794e12f2d7bd8cd9a38111cb5b7a9c71',1,'acelerometro_lectura_y():&#160;acelerometro.c']]],
  ['acelerometro_5flectura_5fz_11',['acelerometro_lectura_z',['../acelerometro_8c.html#ae10a8bda4f78b34f257a52c5b4e8b081',1,'acelerometro_lectura_z():&#160;acelerometro.c'],['../ubit_8h.html#ae10a8bda4f78b34f257a52c5b4e8b081',1,'acelerometro_lectura_z():&#160;acelerometro.c']]]
];
