var searchData=
[
  ['acc_68',['ACC',['../acelerometro_8c.html#a09fc148003f20ecc4834d4ea6aefb15c',1,'acelerometro.c']]],
  ['acc_5fctrl_5freg1_69',['ACC_CTRL_REG1',['../acelerometro_8c.html#a4261ed5ff8ba2ae0b2000c312f46d5ad',1,'acelerometro.c']]],
  ['acc_5fout_5fx_70',['ACC_OUT_X',['../acelerometro_8c.html#a83ea82a0ea23a77aad53a26efeee72b7',1,'acelerometro.c']]],
  ['acc_5fout_5fy_71',['ACC_OUT_Y',['../acelerometro_8c.html#a462e86f76f74f9b19a562683572ffb44',1,'acelerometro.c']]],
  ['acc_5fout_5fz_72',['ACC_OUT_Z',['../acelerometro_8c.html#a5aa358a5ac2183e9e1bd133229a42588',1,'acelerometro.c']]]
];
