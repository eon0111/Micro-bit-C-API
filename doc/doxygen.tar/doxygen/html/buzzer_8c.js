var buzzer_8c =
[
    [ "buzzer_reproduce_nota", "buzzer_8c.html#a8fbdbbfad51a8e79222b10272cb72587", null ],
    [ "periodo_us", "buzzer_8c.html#adcbbf401f9d2353e9dd4488e77f5f944", null ]
];