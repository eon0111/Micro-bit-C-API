var display_8c =
[
    [ "abs", "display_8c.html#a3aa069ac3980707dae1e0530f50d59e4", null ],
    [ "display_apaga_LED", "display_8c.html#af0964c0173cf855ab8868cbba9aaa93b", null ],
    [ "display_cambia_intensidad", "display_8c.html#afb70e9b12379530cabaf588182fb75f1", null ],
    [ "display_char2codi", "display_8c.html#aeac7f19bcea91c0e96fa964a5112bbd7", null ],
    [ "display_enciende_LED", "display_8c.html#a0f86055084066f0712c204c37f4f4a2c", null ],
    [ "display_limpia", "display_8c.html#a0bb1a525c22f32488ebdaeee7e95524d", null ],
    [ "display_muestra_imagen", "display_8c.html#a5693f80a483d2d5723b0bb9959d1e5ba", null ],
    [ "display_muestra_secuencia", "display_8c.html#a9a969fc6cbc67ee3ebfaeed5e0489622", null ],
    [ "display_muestra_sprite", "display_8c.html#a7b5e0aed3dadbc699fe4bacb076cf05e", null ],
    [ "display_muestra_texto", "display_8c.html#a9e70f57dd0306ec0b6410078ca9233a0", null ]
];