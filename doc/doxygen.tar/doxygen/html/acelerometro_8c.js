var acelerometro_8c =
[
    [ "abs", "acelerometro_8c.html#a3aa069ac3980707dae1e0530f50d59e4", null ],
    [ "ACC", "acelerometro_8c.html#a09fc148003f20ecc4834d4ea6aefb15c", null ],
    [ "ACC_CTRL_REG1", "acelerometro_8c.html#a4261ed5ff8ba2ae0b2000c312f46d5ad", null ],
    [ "ACC_OUT_X", "acelerometro_8c.html#a83ea82a0ea23a77aad53a26efeee72b7", null ],
    [ "ACC_OUT_Y", "acelerometro_8c.html#a462e86f76f74f9b19a562683572ffb44", null ],
    [ "ACC_OUT_Z", "acelerometro_8c.html#a5aa358a5ac2183e9e1bd133229a42588", null ],
    [ "PI", "acelerometro_8c.html#a598a3330b3c21701223ee0ca14316eca", null ],
    [ "RAD_A_GRAD", "acelerometro_8c.html#abda6f2b4e574e9483c67e44047d31101", null ],
    [ "acelerometro_inclinacion_eje_x", "acelerometro_8c.html#a73ffcf1f3c69bbd2dd6498316effc4f5", null ],
    [ "acelerometro_inclinacion_eje_y", "acelerometro_8c.html#a2154bc2bdff0aa2c259f576923933212", null ],
    [ "acelerometro_inicializa", "acelerometro_8c.html#a5fd0b6fd546f22ed220baf20ad244cc5", null ],
    [ "acelerometro_lectura_x", "acelerometro_8c.html#a169eee0556749ef07158f51026fdb7c4", null ],
    [ "acelerometro_lectura_y", "acelerometro_8c.html#a794e12f2d7bd8cd9a38111cb5b7a9c71", null ],
    [ "acelerometro_lectura_z", "acelerometro_8c.html#ae10a8bda4f78b34f257a52c5b4e8b081", null ]
];