var misc_8c =
[
    [ "TEMP_BASE", "misc_8c.html#a988cceb9ccd460fea3674f7b8c5fef44", null ],
    [ "TEMP_DATA", "misc_8c.html#adc684174a0c8ca786a5a8fd1f95e03e6", null ],
    [ "TEMP_DATARDY", "misc_8c.html#a57e6c92134d09fef52b577bb99381a4c", null ],
    [ "TEMP_TASK_START", "misc_8c.html#affc9390ebceabfe04c27e5717370901e", null ],
    [ "TMP_STEP", "misc_8c.html#ad467fd9305e3163eae7efea4a1586e8c", null ],
    [ "init", "misc_8c.html#a02fd73d861ef2e4aabb38c0c9ff82947", null ],
    [ "microbit_inicializa_hardware", "misc_8c.html#a1266222f9978ad2a61f052aad2cdc0e7", null ],
    [ "termometro_lectura", "misc_8c.html#a08479db9e20ec26a78eb8c0790470870", null ],
    [ "temp_base", "misc_8c.html#af9fd7ce4bb7ab1ba969ce7c2953567a9", null ],
    [ "temp_data", "misc_8c.html#a81df549f0ef543a2d326abcdcd2c3058", null ],
    [ "temp_datardy", "misc_8c.html#aeb4fd8ee8faa8af54af4fc23bf5a0c02", null ],
    [ "temp_task_start", "misc_8c.html#a17746a142fef4418bc596f8793fafaba", null ]
];